import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useUser } from "@clerk/react";
import { getBaseUrl } from "@/lib/api";
import { getAuthToken } from "@/lib/auth-token";
import { CheckCircle2 } from "lucide-react";

const SPORTS = [
  { name: "游泳", emoji: "🏊" },
  { name: "瑜伽", emoji: "🧘" },
  { name: "普拉提", emoji: "🤸" },
  { name: "足球", emoji: "⚽" },
  { name: "籃球", emoji: "🏀" },
  { name: "網球", emoji: "🎾" },
  { name: "羽毛球", emoji: "🏸" },
  { name: "拳擊", emoji: "🥊" },
  { name: "跑步", emoji: "🏃" },
  { name: "舞蹈", emoji: "💃" },
  { name: "高爾夫球", emoji: "⛳" },
  { name: "劍擊", emoji: "🤺" },
  { name: "田徑", emoji: "🏅" },
  { name: "乒乓球", emoji: "🏓" },
  { name: "跆拳道", emoji: "🥋" },
  { name: "排球", emoji: "🏐" },
];

const AGE_GROUPS = [
  { id: "兒童", emoji: "🧒", desc: "12歲以下" },
  { id: "青少年", emoji: "🧑", desc: "12–17歲" },
  { id: "成人", desc: "18歲以上" },
  { id: "長者", desc: "60歲以上" },
];

const HK_DISTRICTS = [
  { name: "中西區" }, { name: "灣仔" }, { name: "東區" }, { name: "南區" },
  { name: "油尖旺" }, { name: "深水埗" }, { name: "九龍城" }, { name: "黃大仙" }, { name: "觀塘" },
  { name: "葵青" }, { name: "荃灣" }, { name: "屯門" }, { name: "元朗" },
  { name: "北區" }, { name: "大埔" }, { name: "沙田" }, { name: "西貢" }, { name: "離島" },
];

const STEPS = [
  { id: 1, title: "您好，請告訴我們您的姓名", subtitle: "方便我們為您提供個人化體驗" },
  { id: 2, title: "您想搵邊類運動嘅教練？", subtitle: "可多選，我哋用此為您推薦合適教練" },
  { id: 3, title: "教練教嘅年齡層？", subtitle: "您或您的小朋友屬於哪個年齡層？（可多選）" },
  { id: 4, title: "您偏好哪個地區上課？", subtitle: "選擇方便您的地區，我們優先推薦附近的教練（可多選）" },
];

function isAsciiOnly(s: string) {
  return /^[\x00-\x7F]*$/.test(s);
}

function formatDisplayName(last: string, first: string) {
  if (!last && !first) return "";
  if (!last) return first;
  if (!first) return last;
  return (isAsciiOnly(last) && isAsciiOnly(first)) ? `${last} ${first}` : `${last}${first}`;
}

export default function Onboarding() {
  const [step, setStep] = useState(1);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [nameError, setNameError] = useState("");
  const [selectedSports, setSelectedSports] = useState<string[]>([]);
  const [selectedAgeGroups, setSelectedAgeGroups] = useState<string[]>([]);
  const [selectedDistricts, setSelectedDistricts] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [, navigate] = useLocation();
  const { user } = useUser();

  const toggle = (arr: string[], setArr: (v: string[]) => void, val: string) =>
    setArr(arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val]);

  const progress = (step / STEPS.length) * 100;

  const handleNext = () => {
    if (step === 1) {
      if (!firstName.trim() || !lastName.trim()) {
        setNameError("請輸入您的姓氏及名字");
        return;
      }
      setNameError("");
    }
    setStep(s => s + 1);
  };

  async function finish() {
    setSaving(true);
    try {
      const token = await getAuthToken();
      await fetch(`${getBaseUrl()}/api/user/profile`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          firstName: firstName.trim() || undefined,
          lastName: lastName.trim() || undefined,
          preferredSports: selectedSports,
          preferredAgeGroups: selectedAgeGroups,
          preferredDistricts: selectedDistricts,
          onboardingCompleted: true,
        }),
      });
      navigate("/");
    } catch {
      setSaving(false);
    }
  }

  async function skip() {
    try {
      const token = await getAuthToken();
      await fetch(`${getBaseUrl()}/api/user/profile`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ onboardingCompleted: true }),
      });
    } catch {}
    navigate("/");
  }

  const currentStep = STEPS[step - 1];
  const displayName = formatDisplayName(lastName, firstName);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-white to-primary/10 flex flex-col items-center justify-center px-4 py-10">
      <div className="w-full max-w-lg">

        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-3">
            <div className="h-9 w-9 rounded-xl bg-primary flex items-center justify-center text-primary-foreground font-bold text-base shadow-md">運</div>
            <span className="text-xl font-bold font-display">運對</span>
          </div>
          <p className="text-muted-foreground text-sm">
            {user?.firstName ? `歡迎，${user.firstName}！` : "歡迎加入！"} 先讓我們了解您一下 👋
          </p>
        </div>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex justify-between text-xs text-muted-foreground mb-2">
            <span>步驟 {step} / {STEPS.length}</span>
            <span>{Math.round(progress)}% 完成</span>
          </div>
          <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
          </div>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-xl border border-border/50 p-7">
          <h2 className="text-xl font-bold font-display mb-1">{currentStep.title}</h2>
          <p className="text-sm text-muted-foreground mb-6">{currentStep.subtitle}</p>

          {/* Step 1 — Name */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="lastName">姓氏</Label>
                  <Input
                    id="lastName"
                    placeholder="例：陳 / Chan"
                    value={lastName}
                    onChange={e => { setLastName(e.target.value); setNameError(""); }}
                    className="h-11"
                    autoFocus
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="firstName">名字</Label>
                  <Input
                    id="firstName"
                    placeholder="例：大文 / Felix"
                    value={firstName}
                    onChange={e => { setFirstName(e.target.value); setNameError(""); }}
                    className="h-11"
                    onKeyDown={e => e.key === "Enter" && handleNext()}
                  />
                </div>
              </div>
              {nameError && <p className="text-sm text-destructive">{nameError}</p>}
              {firstName && lastName && (
                <div className="flex items-center gap-2 text-sm text-primary bg-primary/5 rounded-lg px-3 py-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  您好，{displayName}！
                </div>
              )}
            </div>
          )}

          {/* Step 2 — Sports */}
          {step === 2 && (
            <div className="grid grid-cols-3 gap-2">
              {SPORTS.map(sport => {
                const selected = selectedSports.includes(sport.name);
                return (
                  <button
                    key={sport.name}
                    type="button"
                    onClick={() => toggle(selectedSports, setSelectedSports, sport.name)}
                    className={`relative flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl border text-sm font-medium transition-all ${
                      selected
                        ? "bg-primary border-primary text-primary-foreground shadow-sm"
                        : "bg-white border-border text-foreground hover:border-primary/50 hover:bg-primary/5"
                    }`}
                  >
                    {selected && (
                      <CheckCircle2 className="absolute top-1.5 right-1.5 w-3 h-3 text-primary-foreground/80" />
                    )}
                    <span className="text-2xl leading-none">{sport.emoji}</span>
                    <span className="text-xs">{sport.name}</span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Step 3 — Age Group */}
          {step === 3 && (
            <div className="grid grid-cols-2 gap-3">
              {AGE_GROUPS.map(ag => {
                const selected = selectedAgeGroups.includes(ag.id);
                return (
                  <button
                    key={ag.id}
                    type="button"
                    onClick={() => toggle(selectedAgeGroups, setSelectedAgeGroups, ag.id)}
                    className={`relative flex flex-col items-center justify-center gap-2 p-5 rounded-xl border text-sm font-medium transition-all ${
                      selected
                        ? "bg-primary border-primary text-primary-foreground shadow-sm"
                        : "bg-white border-border text-foreground hover:border-primary/50 hover:bg-primary/5"
                    }`}
                  >
                    {selected && (
                      <CheckCircle2 className="absolute top-2.5 right-2.5 w-3.5 h-3.5 text-primary-foreground/80" />
                    )}
                    <span className="font-bold text-base">{ag.id}</span>
                    <span className={`text-xs ${selected ? "text-primary-foreground/70" : "text-muted-foreground"}`}>{ag.desc}</span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Step 4 — Preferred Districts */}
          {step === 4 && (
            <div className="grid grid-cols-3 gap-2">
              {HK_DISTRICTS.map(d => {
                const selected = selectedDistricts.includes(d.name);
                return (
                  <button
                    key={d.name}
                    type="button"
                    onClick={() => toggle(selectedDistricts, setSelectedDistricts, d.name)}
                    className={`relative flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl border text-sm font-medium transition-all ${
                      selected
                        ? "bg-primary border-primary text-primary-foreground shadow-sm"
                        : "bg-white border-border text-foreground hover:border-primary/50 hover:bg-primary/5"
                    }`}
                  >
                    {selected && (
                      <CheckCircle2 className="absolute top-1.5 right-1.5 w-3 h-3 text-primary-foreground/80" />
                    )}
                    <span className="text-sm text-center leading-tight">{d.name}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex gap-3 mt-5">
          {step > 1 && (
            <Button variant="outline" onClick={() => setStep(s => s - 1)} className="px-5 h-11">
              ← 返回
            </Button>
          )}
          {step < STEPS.length ? (
            <Button onClick={handleNext} className="flex-1 h-11 font-bold">
              繼續 →
            </Button>
          ) : (
            <Button onClick={finish} disabled={saving} className="flex-1 h-11 font-bold">
              {saving ? "儲存中…" : selectedDistricts.length === 0 ? "略過，完成設定" : "完成設定 🎉"}
            </Button>
          )}
        </div>

        <button
          onClick={skip}
          className="w-full mt-4 text-center text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          跳過，直接瀏覽
        </button>
      </div>
    </div>
  );
}
